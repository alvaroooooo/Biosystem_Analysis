%%Question 1
%% i)
t1=3:3:75;
disp(t1)
ti=linspace(3,75,25);
disp(ti)
%%ii)
t2=-3:1.5:27;
disp(t2)
tii=linspace(-3,27,21);
disp(tii)
%%Question 2
tvec=-pi:pi/10:pi;
xc=@(t)sin(t);
yc=@(t)cos(t);
%%%a)
figure (1)
plot(tvec,xc(tvec),tvec,yc(tvec),'-g')
title('Plot of x vs t and y vs t')
xlabel('Values of t')
ylabel('Values of x and y')
axis tight
%%%b)
figure (2)
plot(xc(tvec),yc(tvec),'-rd','MarkerFaceColor','b')
title('Plot of y vs x')
xlabel('Values of x')
ylabel('Values of y')

%%Question 3
disp('question 3')
BunnyJump(1,3,4,1)

function jumps = BunnyJump(x1,v1,x2,v2)
% First, we see that the following statement has to
% be fulfilled:
% x1 + v1*jumps = x2 + v2*jumps
% if we isolate the vaariable jumps we have:
jumps =((x1-x2)/(v2-v1));
% Then, we have to make sure that the variable
% jumps is a positive integer, i.e.,
if rem(jumps,1)==0 && jumps>0 % (*)
    disp('it is possible')
else
    disp('it is not possible')
end
% (*) one way to verify if a variable is an
% integer is to see if that variable divided
% by 1 leaves a remainder, hence rem(jumps,1)==0
end

