function [raiz,err] = divprom(a,errmax)
% divprom Calcula la ra�z de a con un err de convergencia
% errmax utilizando el m�todo de dividir y promediar. a debe
% ser mayor o igual a 0.
% s a = 0, raiz = 0; err = 0.
% Si a<0, se entrega un error

if a<0
    error('No es posible calcular la raiz de un numero negativo');
elseif a==0
    raiz=0;
    err=0;
    return;
end

raiz_old = (a+1)/2;
err = abs((raiz_old - a)/(raiz_old));
while(true)
    raiz = (raiz_old + a/raiz_old)/2;
    err = abs((raiz - raiz_old)/(raiz));
    raiz_old = raiz;
    if(err<errmax)
        break
    end
end

end

