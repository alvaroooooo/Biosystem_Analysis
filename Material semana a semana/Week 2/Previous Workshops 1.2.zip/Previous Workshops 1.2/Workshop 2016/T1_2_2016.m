%% Parte I)
% a)
t = 4:6:35
x = -3:11:50
t1 = linspace(4,34,6)
x1 = linspace(-3,41,5)

%b)
%Declaramos las funciones an�nimas
xmar  = @(t) sin(t) .* ( exp(cos(t)) - 2*cos(4*t) - (sin(t/12)).^5);
ymar  = @(t) cos(t) .* ( exp(cos(t)) - 2*cos(4*t) - (sin(t/12)).^5) ;

% Generamos el vector con los dos puntos
tvec = 0:1/16:100

plot(tvec,xmar(tvec),'g-.',tvec,ymar(tvec))
title('x vs t junto a y vs t')
xlabel('tiempo')
ylabel('f(t)')
legend('x','y')
figure

plot(xmar(tvec),ymar(tvec),'rd','MarkerFaceColor','b')
title('y vs x en la curva de mariposa')
xlabel('x')
ylabel('y')
% N�tese que se utiliza el comando MarkerFaceColor para cambiar el relleno

% c)Para esto se llama a la funcion programada "divprom"

% Definimos el error m�ximo
errmax = 1e-5;
a = [0 3 5 81 -3];
for i=1:length(a)
    [raiz(i),err(i)] = divprom(a(i),errmax);
    fprintf('\nLa raiz de %3.0f es %3.4f con un error de: %6.9f',a(i),raiz(i),err(i))
end

% a(1): a = 0 debe entregar inmediatamente el valor 0, puesto que el m�todo
% dividir y promediar no es aplicable en este caso de manera directa. Para
% esto se puede utilizar el comando return en el c�digo de la funci�n divprom.
% Para 3,5 y 81 entrega las ra�ces correctas.
% para a = -3; entrega mensaje de error.
% Los vectore