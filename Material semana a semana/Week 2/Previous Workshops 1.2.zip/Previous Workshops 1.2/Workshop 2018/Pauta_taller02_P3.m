function [T_bubble,y_bubble,k] = Pauta_taller02_P3(epsilon)
% Definimos parametros del modelo
param_etanol  = [5.24677,1598.673,-46.424];
param_metanol = [5.20409,1581.341,-33.5];
param_agua    = [6.20963,2354.731,7.559];

% Definimos condiciones de operacion
Pt = 1;           % [bar]
x  = [.2,.3,.5];  % composiciones molares de 20%, 30% y 50% para etanol, metanol y agua respectivamente
n  = 3;           % este indicador podria haber sido cualquier otro (1, 2 o 3)

% Error permitido
tol = epsilon;

%% Inicio del algoritmo
% Paso i)  T[k]
T_k   = x*tempVapor([param_etanol;param_metanol;param_agua],Pt);  % Aqui estamos aprovechando el producto matricial para multiplicar y sumar a la vez

% Paso ii) P[n]
P_i   = pressVapor([param_etanol;param_metanol;param_agua],T_k);
alpha = P_i/P_i(n);
P_n   = Pt/(x*alpha);                                            % Aqui nuevamente estamos aprovechando el producto matricial para multiplicar y sumar a la vez

% Paso iii) T[k+1]
T_kk  = tempVapor(param_agua,P_n);

% Paso iv)
k = 0;
while abs(T_kk - T_k)>tol
    k = k + 1;
    T_k = T_kk;
    
    % En adelante repetimos desde el Paso ii) P[k]
    P_i   = pressVapor([param_etanol;param_metanol;param_agua],T_k);
    alpha = P_i/P_i(n);
    P_n   = Pt/(x*alpha);
    
    % Paso iii) T[k+1]
    if (n == 1)
        T_kk  = tempVapor(param_etanol,P_n);
    elseif (n == 2)
        T_kk  = tempVapor(param_metanol,P_n);
    else
        T_kk  = tempVapor(param_agua,P_n);
    end
end

% Paso v)
T_bubble = T_kk;
y_bubble = (x'.*P_i)/Pt;


function Ti = tempVapor(param_Antoine,Pi)
A  = param_Antoine(:,1);
B  = param_Antoine(:,2);
C  = param_Antoine(:,3);
Ti = B./(A - log10(Pi)) - C;

function Pi = pressVapor(param_Antoine,Ti)
A  = param_Antoine(:,1);
B  = param_Antoine(:,2);
C  = param_Antoine(:,3);
Pi = 10.^(A - B./(Ti + C));