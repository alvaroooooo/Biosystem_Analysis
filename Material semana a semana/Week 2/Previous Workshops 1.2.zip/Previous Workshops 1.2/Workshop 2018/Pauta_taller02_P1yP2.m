% Taller 02'2018 - Pauta 
% a)
% i)
t = linspace(3,75,75/3)
% ii)
x = linspace(-3,27,(27-(-3))/1.5)
% b) 
t = -pi:(pi/10):pi;
x = cos(t);
y = sin(t);
figure (1)
plot(t,x)
hold on
plot(t,y,'--g')
xlabel('t')
ylabel('x,y')
title('Grafico cartesiano')
axis tight
figure (2)
plot(x,y,'-dr','MarkerFaceColor','b')
xlabel('x')
ylabel('y')
title('Grafico de fases')