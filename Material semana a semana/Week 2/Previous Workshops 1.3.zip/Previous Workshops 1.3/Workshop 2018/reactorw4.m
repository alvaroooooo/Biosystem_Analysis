% Workshop 4 
function [sys, x0,str,ts]=reactorw4(t,x,u,flag)
switch flag
   case 0
   [sys, x0,str,ts]=mdlInitializeSizes;
   case 1 
   sys=mdlDerivatives(t,x,u);
   case 3
   sys=mdlOutputs(t,x,u);
   case {2,4,9}
   sys=[];
   otherwise
     error(['Unhandled flag = ',num2str(flag)]);
end
%%
function [sys,x0,str,ts]=mdlInitializeSizes
sizes=simsizes;
sizes.NumContStates =5; % (
sizes.NumDiscStates =0;
sizes.NumOutputs    =5; % (
sizes.NumInputs     =0; % 
sizes.DirFeedthrough=0;
sizes.NumSampleTimes=1;
sys = simsizes(sizes);

% Initial State Values
CA0 = 1;  % scaled value 
CB0 = 2; % scaled value
CD0=1;
CS0=0;
CR0=0;
x0=[CA0,CB0,CD0,CR0,CS0];
str=[];
ts=[0 0];
%%
function sys=mdlDerivatives(~,x,u)
%NOMINAL PARAMETERS
k1      =   1  ;     % 
k2      = k1/4  ;     % 

CA=x(1);
CB=x(2);
CD=x(3);
% CR=x(4);
% CS=x(5);

%ODES
% Component A,B,D mass balance
sys(1) = -k1*CA*CB; %% CA
sys(2)=-k1*CA*CB-k2*CB*CD; %% CB
sys(3)=-k2*CB*CD; %% CD
% Products R, S mass balance
sys(4)=k1*CA*CB; %% CR
sys(5)=k2*CB*CD; %% CS


%% 
function sys=mdlOutputs(~,x,~)
sys=[x(1) x(2) x(3) x(4) x(5)];