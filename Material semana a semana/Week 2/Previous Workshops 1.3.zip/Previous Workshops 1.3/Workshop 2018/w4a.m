% Script Workshop 04

function w4a

% time vector 
tspan = (0:0.01:10); 
% initial conditions vector
%       CA0 CB0 CD0 CR0 CS0
x0    = [1   2   1   0   0]; % model

[t,x] = ode15s(@model,tspan,x0);

plot(t,x(:,1),'-g',t,x(:,2),'-b',t,x(:,3),'-r',t,x(:,4),'-m',t,x(:,5),'-c');
title('Dynamics of the concentrations in the reactor');

xlabel('time (min)');
ylabel('Concentration (mol/L)')
legend('[A]','[B]','[D]','[R]','[S]')
end

function sys=model(~,x)

%NOMINAL PARAMETERS
k1      =   1  ;     % 
k2      = k1/4  ;     % 

CA=x(1);
CB=x(2);
CD=x(3);
% CR=x(4);
% CS=x(5);

%ODES
% Component A,B,D mass balance
sys(1) = -k1*CA*CB; %% CA
sys(2)=-k1*CA*CB-k2*CB*CD; %% CB
sys(3)=-k2*CB*CD; %% CD
% Products R, S mass balance
sys(4)=k1*CA*CB; %% CR
sys(5)=k2*CB*CD; %% CS
sys=sys';

end

