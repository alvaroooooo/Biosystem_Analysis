function Taller1pregunta3
t = [0 2];
a0=[0.2, 0.5, 0.4];
[t,r]=ode45(@edo1,t,a0);

figure (1)
plot(t,r(:,1),'mh',t,r(:,2),'cp',t,r(:,3),'gd')
legend ('x','y','z')
title ('Grafico')
xlabel('tiempo')
ylabel('eje y')

end
function dx=edo1(t,x)
dx(1)=5.*x(1).*exp(-x(1).^3)-2.*x(1).^2;
dx(2)=2.*x(1).*sqrt(3)+x(1).*exp(-sqrt(3.*x(2)))-(x(1).*x(2));
dx(3)=(3.*pi.*x(1))/(x(3)-x(2)+x(1)/2)+x(3).*exp(-3)-2.*x(3).*x(1).^2;
dx=dx';
end

