
%% Problema 1
% Uso del solver ode23s para realizar integraci�n num�rica
% de un sistema de ecuaciones diferenciales que caracteriza
% el crecimiento microbiano. El sistema de ecuaciones se encuentra en
% el archivo crec_micro.m

[T,Y] = ode23(@crec_micro,[0 10],[0.1 20 10]');

plot(T,Y(:,1),'r-',T,Y(:,2),'k.-',T,Y(:,3),'b--')
legend('X: Biomasa [g/L]','S: Sustrato [g/L]','O_2: Oxigeno [mg/L]')
xlabel('tiempo [h]')
ylabel('Concentracion')
title('Solucion con ode23')

% Parte 2:
[Y1,I] = max(Y(:,1));
T(I);
fprintf('El sistema debe operar aproximadamente %f horas',T(I));
% El sistema debe operar Aproximadamente 7.63 horas

% % Observaci�n: comparaci�n con el integrador ode45
% [T45,Y45] = ode45(@crec_micro,[0 10],[0.1 20 10]');
% figure
% plot(T45,Y45(:,1),'r-',T45,Y45(:,2),'k.-',T45,Y45(:,3),'b--')
% legend('X: Biomasa','S: Sustrato','O_2: Oxigeno')
% xlabel('tiempo (t)')
% ylabel('Concentracion')
% title('Solucion con ode45')
