function dY = crec_micro(t,y)
% crec_micro Simula el crecimiento microbiano en un biorreactor
%

mu_max =   0.6;    % 1/h
K_S =      0.05;   % g/L
Y_XS =     0.5;    % gbiomasa/gsustrato  
Y_XO2 =    0.001;  % g biomasa / mg oxigeno   
m =        0.08;   % g sustrato / g biomasa h
K_LA =     400;    % 1/h;
O2star   =     8;      % mg/L
m_O2=      100;    % mg_oxigeno/gbiomasa*h

X  = y(1);
S  = y(2);
O2 = y(3);

mu = mu_max * S/(K_S+S);

dY(1) = mu*X
if(S>0)
    dY(2) = -mu*X/Y_XS - m*X;
else
    dY(2) = 0;
end

dY(3) = K_LA * (O2star-O2) - mu*X/Y_XO2 - m_O2*X;
dY=dY(:);
end

