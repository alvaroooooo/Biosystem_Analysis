%% P1
x0=[0.2, 0.5, 0.4] %initial conditions
[t,x]=ode45(@edobonita, [0, 2], x0);%call the ode to solve the system
%t is the row vector with the solution discrete time
%x is the matrix with the solution of the system. Each column shows the values for every unit of time for each variable.
%to call de ode first we put the function name, then the time of integration and finally the initial conditions

%plot the results
plot(t,x(:,1),'kd',t, x(:,2),'hg',t, x(:,3), 'pr')
title('Graphic solution of the system ') %put name to the graph
legend('x solutions','y solutions', 'z solutions') %put legend to the graph
%name the axis
xlabel('time') 
ylabel('x, y, x')

tiempoT1=0;
tiempoT2=0;
i=0
while i<10
    i=i+1;
    tic
    [t,x]=ode45(@edobonita, [0, 2], x0);%call the ode to solve the system
    tiempo1=toc;
    tic
    [t,x]=ode23s(@edobonita, [0, 2], x0);%call the ode to solve the system
    tiempo2=toc;
    tiempoT1=tiempoT1+tiempo1
    tiempoT2=tiempoT2+tiempo2
    i
end

tiempoT1/10
tiempoT2/10
