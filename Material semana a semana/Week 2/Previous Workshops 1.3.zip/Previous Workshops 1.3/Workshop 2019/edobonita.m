function dx = edobonita( t,x )
%function that describes the system of ordinary differential equiations of the workshop
%   x(1)=x
%   x(2)=y
%   x(3)=z
dx(1) = 5*x(1)*exp(-x(1)^3)-2*x(1)^2;
dx(2) = 2*x(1)*sqrt(3)+x(1)*exp(-sqrt(3*x(2)))-x(1)*x(2);
dx(3) = (3*pi*x(1)/(x(3)-x(2)+x(1)/2))+x(3)*exp(-3)-2*x(3)*x(1)^2;
dx=dx';
end
