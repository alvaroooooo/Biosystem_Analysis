function [sys, x0,str,ts]=REACTORLIEB(t,x,u,flag)
switch flag
   case 0
   [sys, x0,str,ts]=mdlInitializeSizes;
   case 1 
   sys=mdlDerivatives(t,x,u);
   case 3
   sys=mdlOutputs(t,x,u);
   case {2,4,9}
   sys=[];
   otherwise
     error(['Unhandled flag = ',num2str(flag)]);
end
%%
function [sys,x0,str,ts]=mdlInitializeSizes
sizes=simsizes;
sizes.NumContStates =2; % (A, T)
sizes.NumDiscStates =0;
sizes.NumOutputs    =2; % (A, T)
sizes.NumInputs     =3; % (Ao, To, Tr)
sizes.DirFeedthrough=0;
sizes.NumSampleTimes=1;
sys = simsizes(sizes);

% Initial State Values
Ai = 0.153;  % scaled value 
Ti = 4.6091; % scaled value
x0=[Ai,Ti];
str=[];
ts=[0 0];
%%
function sys=mdlDerivatives(~,x,u)
% EXOTHERMIC CHEMICAL REACTOR
% Reference: M. L. Liebman, T. F. Edgar and L. S. Lasdon.
% Efficient data reconciliation and estimation for dynamic
% processes using nonlinear programming techniques.
% Comput. Chem. Eng., vol. 16, pp. 963-986, 1992.
%NOMINAL PARAMETERS
q      =     10.0;     % [cm^3/s]
V      =   1000.0;     % [cm^3]
DHr    = -27000.0;     % [cal/gmol]
ro     =      0.001;   % [g/cm^3]
Cp     =      1.0;     % [cal/(g K)]
U      =      5.0e-4;  % [cal/(cm^2 s K)]
Ar     =     10.0;     % [cm^2]
Ko     =      7.86e12; % [1/s]
Ea     =  14090.0;     % [K]
alfad  =      1.0;     % [-]

sA  =    1.0e-6;  % scaling factor of A [gmol/cm^3]
sT  =    100.0;   % scaling factor of T [K]

%ALGEBRAIC EQUATIONS
K    = Ko*exp(-Ea/(x(2)*sT));
con1 = q/V;
con2 = -alfad*K;
con3 = alfad*(-DHr/(ro*Cp))*K;
con4 = -U*Ar/(ro*Cp*V);

%ODES
% Component A mass balance
sys(1) = con1*(u(1) - x(1)) + con2*x(1);
% Energy balance
sys(2) = con1*(u(2) - x(2)) + con3*x(1)*sA/sT + con4*(x(2) - u(3));
%% 
function sys=mdlOutputs(~,x,~)
sys=[x(1) x(2)];