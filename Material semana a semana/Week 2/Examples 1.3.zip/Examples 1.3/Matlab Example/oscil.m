function dtheta = oscil(~,x)
% non-linear pendulum equation
% x(1) = theta
% x(2) = dx(1) = dtheta(1)
% dx(2) = dtheta(2)
l = 0.6; %m
g = 9.81; %m/s

dtheta(1) = x(2);
dtheta(2) = -g/l*sin(x(1));
dtheta=dtheta';

end
