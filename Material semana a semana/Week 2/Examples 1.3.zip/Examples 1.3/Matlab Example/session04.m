%% Example IVP: Oscillation in a pendulum

%% Case 1 (small displacements)
y0 = [pi/8, 0];
% Non linear
[tnl,ynl] = ode45(@oscil,[0 20],y0);
[tl,yl] = ode45(@oscil_l,[0 20],y0);
plot(tl,yl(:,1),'r-',tnl,ynl(:,1),'k-')
legend('Linear Approximation','Non Linear Solution')
xlabel('time')
ylabel('\theta')
title('\theta = \pi/8, d \theta / dt = 0')

%% Case 2 (large displacements)
y0 = [pi/2, 0];
figure %creates a new figure
[tnl,ynl] = ode45(@oscil,[0 20],y0);
[tl,yl] = ode45(@oscil_l,[0 20],y0);
plot(tl,yl(:,1),'r-',tnl,ynl(:,1),'k-')
legend('Linear Approximation','Non Linear Solution')
xlabel('time')
ylabel('\theta')
title('\theta = \pi/2, d \theta / dt = 0')